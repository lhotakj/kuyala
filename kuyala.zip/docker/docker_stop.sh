#!/bin/bash
sudo docker stop kuyala
sudo docker rm --force kuyala