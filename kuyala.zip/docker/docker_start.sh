#!/bin/bash
sudo docker run --detach -p 5000:5000 --name kuyala kuyala
